const simplydjs = require('simply-djs')
module.exports = {
  name: "ticket",
  aliases: [""],
  usage: "unban",
  description: "unbans member",
  run: async (client, message, args) => {
    client.on('clickButton', async (button) => {
      // a discord-buttons event which fires when a button gets clicked
      simplydjs.clickBtn(button, {
        embedDesc: '**[Utworzyłeś ticket/a...](https://discord.gg/)**',
        embedColor: '#2f3136', // default: #2f3136
        closeColor: '#2f3136', //default: #2f3136
        closeEmoji: '🔒', // d🔒🔒
        delColor: '#2f3136', // default: #2f3136
        delEmoji: '❌',
        openColor: '#2f3136', // default: #2f3136
        openEmoji: '🔓', // default: 🔓
        timeout: true, // default: true | Needs to be boolean (true/false)
        cooldownMsg: 'Otwierasz Ticketa, za szybko. Zwolnij!',
        categoryID: args[0],
        role: args[1] // Role which sees the ticket channel (like Support Role)
      })
    })

    // message event
    // setup-ticket command

    simplydjs.ticketSystem(message, message.channel, {
      embedDesc:'Posiadasz pilną sprawę, do administracji? Stwórz ticket!' ,
      embedColor: '#2f3136', // default: #2f3136
      embedFoot: 'footer text', // default: message.guild.name
      emoji: '🎫', // default:, 🎫
      color: '#2f3136', // default: #2f3136
    })
  }
}

